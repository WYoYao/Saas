;
(function () {
    v.pushComponent({
        name: 'addSystem',
        data: {
            majorTypeArr: [{
                code: null,
                name: "全部",
                content: []
            }],//专业列表
            systemTypeArr: [{
                code: null,
                name: "全部",
            }],//系统列表
            buildSystemTree: [],

        },
        computed: {

        },
        filters: {

        },
        methods: {

        },
        watch: {

        },
    })
})();