var getKeybySource = function() {

}